const User = require('../auth/User')

const saveToWatch=(req, res)=>{
    console.log(req.body);
}

module.exports={
    saveToWatch
}